<?php

class DatabaseInitialization
{
    private $conn;

    public function __construct($host, $username, $password, $dbname)
    {
        $this->conn = new mysqli($host, $username, $password, $dbname);
        if ($this->conn->connect_error) {
            die("Could not connect to MySQL: " . $this->conn->connect_error);
        }
        mysqli_set_charset($this->conn, 'utf8');
    }

    public function getConnection()
    {
        return $this->conn;
    }

    public function createDatabase()
    {
        $sql = "CREATE DATABASE IF NOT EXISTS thebookshelf";
        if ($this->conn->query($sql) === TRUE) {
            //echo "Database created successfully";
        } else {
            echo "Error creating database: " . $this->conn->error;
        }
    }

    public function selectDatabase()
    {
        $this->conn->select_db('thebookshelf');
    }

    public function createLoginDetailsTable()
    {
        $sql = "CREATE TABLE IF NOT EXISTS login_details (
            emailid VARCHAR(255) PRIMARY KEY,
            password VARCHAR(255) NOT NULL,
            firstname VARCHAR(255) NOT NULL,
            lastname VARCHAR(255) NOT NULL)";
        if ($this->conn->query($sql) === TRUE) {
            // echo "Table login_details created successfully";
        } else {
            echo "Error creating table: " . $this->conn->error;
        }
    }

    public function createBookDetailsTable()
    {

        $tableExists = false;
        $checkTableQuery = "SHOW TABLES LIKE 'book_details'";
        $result = $this->conn->query($checkTableQuery);
        if ($result->num_rows > 0) {
            $tableExists = true;
        }

        if (!$tableExists) {
            $sql = "CREATE TABLE book_details (
                book_id INT AUTO_INCREMENT PRIMARY KEY,
                book_name VARCHAR(255),
                book_description VARCHAR(2000),
                book_price DECIMAL(10, 2),
                book_author VARCHAR(255),
                book_type VARCHAR(255),
                uploadImage VARCHAR(255)
            )";
            
            if ($this->conn->query($sql) === TRUE) {
                //echo "Table book_details created successfully<br>";
                
                $insertQuery = "
                    INSERT INTO `book_details` (`book_name`, `book_description`, `book_price`, `book_author`, `book_type`, `uploadImage`) VALUES
                        ('The Shining', 'Written by Stephen King, \'The Shining\' is a chilling tale of a family\'s winter stay at an isolated hotel, where the father\'s descent into madness and the supernatural forces at play threaten their sanity and survival. With its eerie atmosphere and psychological depth, this classic horror novel continues to captivate readers with its relentless suspense and haunting imagery.', 12.99, 'Stephen King', 'horror', 'The_Shining.jpg'),
                        ('Bird Box', 'Josh Malerman\'s \'Bird Box\' is a heart-pounding thriller set in a world where mysterious creatures drive people to deadly violence when seen. Malorie, along with her two children, must navigate blindfolded through a treacherous landscape to reach safety. Tension grips every page as the characters confront the unknown and the terrifying consequences of opening their eyes.', 10.50, 'Josh Malerman', 'horror', 'Bird_Box.jpg'),
                        ('Harry Potter and the Sorcerer\'s Stone', 'J.K. Rowling\'s \'Harry Potter and the Sorcerer\'s Stone\' follows the journey of a young boy, Harry Potter, as he discovers his magical heritage and attends Hogwarts School of Witchcraft and Wizardry. Filled with friendship, adventure, and the battle between good and evil, this beloved fantasy novel has enchanted readers of all ages for decades.', 8.99, 'J.K. Rowling', 'kids', 'Harry_Potter_philosopher_Stone.jpg'),
                        ('Charlotte\'s Web', 'E.B. White\'s timeless classic, \'Charlotte\'s Web\', tells the heartwarming story of a pig named Wilbur and his unlikely friendship with a spider named Charlotte. Through their adventures on the Zuckerman farm, readers learn about loyalty, love, and the beauty of friendship that transcends differences. This gentle tale is a must-read for children and adults alike.', 6.50, 'E.B. White', 'kids', 'Charlotte_Web.jpg'),
                        ('Watchmen', 'Alan Moore\'s \'Watchmen\' is a groundbreaking graphic novel that deconstructs the superhero genre, presenting a complex narrative set in an alternate version of the 1980s. With intricate artwork by Dave Gibbons, the story explores themes of power, morality, and the nature of heroism, offering a thought-provoking and visually stunning reading experience.', 19.99, 'Alan Moore', 'comic', 'The_Watchmen.jpg'),
                        ('Saga', 'Brian K. Vaughan and Fiona Staples\' \'Saga\' is a sweeping space opera that follows the intergalactic journey of two lovers from warring species as they struggle to protect their newborn daughter. Filled with vivid characters, imaginative worlds, and epic conflicts, this acclaimed comic series pushes the boundaries of storytelling and captivates readers with its emotional depth and stunning artwork.', 24.99, 'Brian K. Vaughan, Fiona Staples', 'poetry', 'The_Saga.jpg'),
                        ('To Kill a Mockingbird', 'Harper Lee\'s \'To Kill a Mockingbird\' is a powerful exploration of racial injustice and moral growth in the American South during the 1930s. Through the eyes of young Scout Finch, readers witness her father, lawyer Atticus Finch, defend a black man falsely accused of raping a white woman. This timeless classic resonates with its themes of empathy, compassion, and the fight for equality.', 11.50, 'Harper Lee', 'fiction', 'To_Kill_a_Mockingbird.jpg'),
                        ('The Great Gatsby', 'F. Scott Fitzgerald\'s \'The Great Gatsby\' is a masterpiece of American literature, capturing the essence of the Jazz Age and the pursuit of the American Dream. Set in the opulent world of Long Island\'s elite, the novel follows the enigmatic Jay Gatsby\'s obsession with the beautiful Daisy Buchanan, revealing the emptiness and disillusionment beneath the glittering facade of wealth and privilege.', 9.99, 'F. Scott Fitzgerald', 'fiction', 'The_Great_Gatsby.jpg'),
                        ('The Art of Happiness', 'In \'The Art of Happiness\', His Holiness the Dalai Lama and psychiatrist Howard C. Cutler explore the keys to finding true happiness in today\'s fast-paced world. Drawing on Buddhist philosophy and Western psychology, they offer practical advice and insightful teachings on cultivating compassion, gratitude, and inner peace. Through engaging conversations and profound wisdom, this timeless guide invites readers to embark on a journey of self-discovery and personal transformation, discovering the joy that arises from living a life of purpose and contentment.', 15.99, 'Dalai Lama, Howard C. Cutler', 'philosophy', 'The_Art_of_Happiness.jpg'),
                        ('The City of Ember', 'Jeanne DuPrau\'s \'The City of Ember\' is a gripping dystopian novel set in an underground city where darkness and decay threaten the survival of its inhabitants. When Lina and Doon uncover clues left behind by the city\'s founders, they embark on a dangerous adventure to unlock its secrets and find a way to save their home. Filled with suspense and intrigue, this captivating tale explores themes of courage, friendship, and the resilience of the human spirit in the face of adversity.', 12.50, 'Jeanne DuPrau', 'adventure', 'The_City_of_Ember.jpg'),
                        ('Think Like a Monk', 'In \'Think Like a Monk\', Jay Shetty draws upon his experiences as a former monk and his insights from Eastern philosophy to offer a transformative guide to finding purpose, peace, and fulfillment in a chaotic world. Through practical exercises, profound wisdom, and inspiring stories, Shetty reveals how to overcome negative thought patterns, cultivate gratitude, and live with intention. Blending ancient teachings with modern principles, this empowering book empowers readers to embrace a monk mindset and create a life of meaning, joy, and inner harmony.', 17.99, 'Jay Shetty', 'philosophy', 'Think_Like_a_Monk.jpg');
                ";

                if ($this->conn->query($insertQuery) === TRUE) {
                    //echo "Data inserted successfully";
                } else {
                    echo "Error inserting data: " . $this->conn->error;
                }
            } else {
                echo "Error creating table: " . $this->conn->error;
                return;
            }
        } else {
            //echo "Table book_details already exists";
        }  

    }

    public function createOrderDetailsTable()
    {
        $sql = "CREATE TABLE IF NOT EXISTS order_details(
            order_id INT AUTO_INCREMENT PRIMARY KEY,
            emailid VARCHAR(255),
            full_name VARCHAR(255),
            contact_number BIGINT(10),
            Address VARCHAR(255),
            city VARCHAR(255),
            province VARCHAR(255),
            postalcode VARCHAR(255),
            order_date DATE DEFAULT CURRENT_TIMESTAMP(),
            FOREIGN KEY (emailid) REFERENCES login_details(emailid)
        )";
        if ($this->conn->query($sql) == TRUE) {
            //   echo"Table checkout created successfully";
        } else {
            echo "Error creating table:" . $this->conn->error;
        }
    }

    public function createOrderBookDetailsTable()
    {
        $sql = "CREATE TABLE IF NOT EXISTS order_book_details(
        order_id INT,
        book_id INT,
        quantity INT,
        PRIMARY KEY (order_id, book_id), 
        FOREIGN KEY (order_id) REFERENCES order_details(order_id)
        )";
        if ($this->conn->query($sql) == TRUE) {
            //   echo"Table checkout created successfully";
        } else {
            echo "Error creating table:" . $this->conn->error;
        }
    }
    
    public function createContactUsTable()
    {
        $sql = "CREATE TABLE IF NOT EXISTS contactus_details(
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(255),
        last_name VARCHAR(255),
        email VARCHAR(255),
        contact_number BIGINT(10),
        province VARCHAR(255),
        message VARCHAR(255))";
        if ($this->conn->query($sql) == TRUE) {
            // echo"Table checkout created successfully";
        } else {
            echo "Error creating table:" . $this->conn->error;
        }
    }
    public function closeConnection()
    {
        $this->conn->close();
    }
}

$db = new DatabaseInitialization('localhost', 'root', '', '');
$db->createDatabase();
$db->selectDatabase();
$db->createLoginDetailsTable();
$db->createBookDetailsTable();
$db->createOrderDetailsTable();
$db->createContactUsTable();
$db->createOrderBookDetailsTable();
$db->closeConnection();

?>