<?php
class DatabaseConnection
{
    private $conn;
    const DB_USER = 'root';
    const DB_HOST = 'localhost';
    const DB_PASSWORD = '';
    const DB_NAME = 'thebookshelf';

    public function __construct()
    {
        $this->conn = new mysqli(self::DB_HOST, self::DB_USER, self::DB_PASSWORD, self::DB_NAME);
        if ($this->conn->connect_error) {
            die("Could not connect to MySQL: " . $this->conn->connect_error);
        }
        mysqli_set_charset($this->conn, 'utf8');
    }

    public function getConnection()
    {
        return $this->conn;
    }

    public function closeConnection()
    {
        $this->conn->close();
    }

    public function loginUser($email, $password)
    {
        $sql = "SELECT * FROM login_details WHERE EmailId = ? AND Password = ?";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "ss", $email, $password);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);

        if (mysqli_stmt_num_rows($stmt) > 0) {
            mysqli_stmt_close($stmt);
            return true;
        } else {
            mysqli_stmt_close($stmt);
            return false;
        }
    }

    public function userExists($email)
    {
        $sql = "SELECT * FROM login_details WHERE EmailId = ?";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);

        mysqli_stmt_store_result($stmt);

        $numRows = mysqli_stmt_num_rows($stmt);

        $result = $numRows > 0;
        return $result;
        
    }

    public function registerUser($email, $password, $firstname, $lastname)
    {
        $sql = "INSERT INTO login_details (emailid, password, firstname, lastname) VALUES (?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssss", $email, $password, $firstname, $lastname);
        $stmt->execute();
        if ($stmt->affected_rows > 0) {
            return true;
        } else {
            return false;
        }
    }
    public function isAdmin($email, $password)
    {
        if ($email === "admin@thebookshelf.com" && $password === "Admin@123") {
            $_SESSION['email'] = $email;
            $_SESSION['is_admin'] = true; // Marking the user as admin
            return true;
        }
        return false;
    }
    public function getUserDetails($email)
    {
        $sql = "SELECT firstname, lastname FROM login_details WHERE emailid = ?";
        $stmt = mysqli_prepare($this->conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $firstname, $lastname);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);

        return array('firstname' => $firstname, 'lastname' => $lastname);
    }

    public function getBookDetailsById($bookId)
    {
        $sql = "SELECT book_id, book_name, book_description, book_price, book_author, book_type, uploadImage FROM book_details WHERE book_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $bookId);
        $stmt->execute();
        $stmt->bind_result($book_id, $book_name, $book_description, $book_price, $book_author, $book_type, $uploadImage);

        // Fetch the result
        $stmt->fetch();

        // Store the result in an associative array
        $bookDetails = [
            'book_id' => $book_id,
            'book_name' => $book_name,
            'book_description' => $book_description,
            'book_price' => $book_price,
            'book_type' => $book_type,
            'book_author' => $book_author,
            'uploadImage' => $uploadImage
        ];

        $stmt->close();

        return $bookDetails;
    }

    public function deleteBookById($bookId)
    {
        $sql = "DELETE FROM book_details WHERE book_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("i", $bookId);
        $result = $stmt->execute();

        return $result;
    }

    public function updateBookById($bookId, $book_name, $book_description, $book_price, $book_author, $book_type, $uploadImage)
    {
        $sql = "UPDATE book_details
                SET
                    book_name = ?,
                    book_description = ?,
                    book_price = ?,
                    book_author = ?,
                    book_type = ?,
                    uploadImage = ?
                WHERE
                    book_id = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssdsssi", $book_name, $book_description, $book_price, $book_author, $book_type, $uploadImage, $bookId);
        $result = $stmt->execute();

        return $result;
    }

    public function getAllBookDetails()
    {
        $books = array();

        $sql = "SELECT book_id, book_name, book_description, book_price, book_author, uploadImage FROM book_details";
        $result = $this->conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $books[] = $row;
            }
        }

        return $books;
    }
    //code for filtering data according to book type
    public function getBooksByType($type)
    {
        $books = array();
        $sql = "SELECT book_id, book_name, book_description, book_price, book_author, uploadImage FROM book_details WHERE book_type = ?";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $type);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $books[] = $row;
            }
        }

        return $books;
    }

    //code for Getting the og Books Genres
    public function getBooksGenre()
    {
        $booksGenre = array();
        $sql = "SELECT book_type FROM book_details GROUP BY book_type";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $booksGenre[] = $row;
            }
        }

        return $booksGenre;
    }


    public function insertBookDetails($book_name, $book_description, $book_price, $book_author, $book_type, $uploadImage)
    {
        $query = "INSERT INTO book_details(Book_name, Book_Description, Book_Price, Book_Author, Book_Type,uploadImage) VALUES (?, ?, ?, ?, ?,?)";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, 'ssssss', $book_name, $book_description, $book_price, $book_author, $book_type, $uploadImage);
        $result = mysqli_stmt_execute($stmt);

        if ($result) {
            $folder = "upload/";
            $target_file = $folder . basename($_FILES["uploadImage"]["name"]);
            $uploadSuccessfull = 1;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            if (move_uploaded_file($_FILES["uploadImage"]["tmp_name"], $target_file)) {
                return "Data uploaded successfully.";
            } else {
                return "Error in uploading the image.";
            }
        } else {
            return "Some error in saving the data: " . mysqli_error($this->conn);
        }
    }
    public function insertOrderDetails($emailid, $full_name, $contact_number, $address, $city, $province, $postalcode)
    {
        $query = "INSERT INTO order_details(emailid, full_name,contact_number,address,city,province,postalcode) VALUES(?,?,?,?,?,?,?)";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, 'ssissss', $emailid, $full_name, $contact_number, $address, $city, $province, $postalcode);
        $result = mysqli_stmt_execute($stmt);
        // Retrieve the inserted order_id
        $order_id = $this->conn->insert_id;

        // Return the inserted order_id
        return $order_id;
    }
    public function insertOrderBookDetails($order_id, $book_id, $quantity)
    {
        $query = "INSERT INTO order_book_details(order_id, book_id,quantity) VALUES(?,?,?)";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, 'iii', $order_id, $book_id, $quantity);
        $result = mysqli_stmt_execute($stmt);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }

    public function insertContactUsDetails($first_name, $last_name, $email, $contact_number, $province, $message)
    {
        $query = "INSERT INTO contactus_details(first_name, last_name, email, contact_number, province, message) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($this->conn, $query);
        mysqli_stmt_bind_param($stmt, 'ssssss', $first_name, $last_name, $email, $contact_number, $province, $message);
        $result = mysqli_stmt_execute($stmt);
        if ($result) {
            return true;
        } else {
            return false;
        }
    }
}

?>