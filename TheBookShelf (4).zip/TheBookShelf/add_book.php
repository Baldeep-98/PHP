<?php
include 'db_conn.php';
include 'validation.php';
session_start();
//setting firstname and lastname from Session
if (isset($_SESSION['email']) && isset($_SESSION['firstname']) && isset($_SESSION['lastname'])) {
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
}
$book_name_error = $book_description_error = $book_price_error = $book_author_error = $book_image_error = $book_type_error = "";

//validations for Adding Book Details
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $book_name = !empty($_POST['book_name']) ? htmlspecialchars($_POST['book_name'], ENT_QUOTES, 'UTF-8') : '';
    $book_description = !empty($_POST['book_description']) ? htmlspecialchars($_POST['book_description'], ENT_QUOTES, 'UTF-8') : '';
    $book_price = !empty($_POST['book_price']) ? $_POST['book_price'] : '';
    $book_author = !empty($_POST['book_author']) ? htmlspecialchars($_POST['book_author'], ENT_QUOTES, 'UTF-8') : '';
    $book_type = !empty($_POST['book_type']) ? $_POST['book_type'] : '';
    $uploadImage = !empty($_FILES['uploadImage']['name']) ? htmlspecialchars($_FILES['uploadImage']['name'], ENT_QUOTES, 'UTF-8') : '';

    if (empty($book_name)) {
        $book_name_error = "Book Name is required";
    } else {
        if (strlen(trim($book_name)) <= 0) {

            $book_name_error = "Enter valid Book Name";
            $book_name = '';
        }
    }

    if (empty($book_description)) {
        $book_description_error = "Book description is required.";
    }
    else {
        if (strlen(trim($book_description)) <= 0) {
            $book_description_error = "Enter valid Book Name";
            $book_description = '';
        }
    }

    if (empty($book_price)) {
        $book_price_error = "Book price is required.";
    } else {
        if (!Validation::validatePrice($book_price)) {
            $book_price_error = "Enter price in valid format";
            $book_price = '';
        }
    }

    if (empty($book_author)) {
        $book_author_error = "Book author is required.";
    } else {
        if (strlen(trim($book_author)) <= 0) {
            $book_author_error = "Enter valid Book author";
            $book_author = '';
        }
    }

    if (empty($book_type) || $book_type === "Select Book") {
        $book_type_error = "Please select a valid book type";
    } 

    if (empty($uploadImage)) {
        $book_image_error = "Book Image is required";
    }

    if (empty($book_name_error) && empty($book_description_error) && empty($book_author_error) && empty($book_price_error) && empty($book_image_error) && empty($book_type_error)) {


        $target_dir = "Imgs/uploads/";
        $target_file = $target_dir . basename($_FILES["uploadImage"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        if (isset($_POST["submit"])) {
            $check = getimagesize($_FILES["uploadImage"]["tmp_name"]);
            if ($check !== false) {
                $uploadOk = 1;
            } else {
                $book_image_error = 'File is not an image.';
                $uploadOk = 0;
            }
        }

        if (file_exists($target_file)) {
            $book_image_error = 'Sorry, file already exists.';
            $uploadOk = 0;
        }

        if ($_FILES["uploadImage"]["size"] > 500000) {
            $book_image_error = 'Sorry, your file is too large.';
            $uploadOk = 0;
        }

        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            $book_image_error = 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.';
            $uploadOk = 0;
        }
        if ($uploadOk == 1) {
            if (move_uploaded_file($_FILES["uploadImage"]["tmp_name"], $target_file)) {
                echo "<script> console.log('The file " . htmlspecialchars(basename($_FILES["uploadImage"]["name"])) . " has been uploaded.') </script>";
            } else {
                echo "<script> console.log('Sorry, there was an error uploading your file.') </script>";
            }
        }

        if ($uploadOk == 1) {

            $dbConnection = new DatabaseConnection();
            $result = $dbConnection->insertBookDetails($book_name, $book_description, $book_price, $book_author, $book_type, $uploadImage);

            if (isset($result)) {
                echo '<script>alert("Book details have been successfully added.");</script>';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Admin - Page</title>
</head>

<body>

    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php">Home</a>
            <a href="Products.php">Books</a>

            <?php
            if (!isset($_SESSION['email'])) {
                ?>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
                <a href="login.php">Login</a>
                <?php
            } else { ?>
                <a href="add_book.php" class="active">Add Book</a>
                <a href="logout.php">Logout</a>
            </div>

            <?php
            echo "<div class='profile-name-container'> <div href='#' class='profile-name'>
                    <img src ='Imgs/user.png' alt='profile icon' class='profile-icon'/>
                    <span> 
                        $lastname, $firstname 
                    </span>
                </div>";
            }
            ?>
    </nav>

    <main>
        <div class="checkout-container">
            <h1>Add a new Book</h1>
            <div class="checkout-card-container">
                <div class="product-card">
                    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" id="admin_form"
                        enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="book_name" class="form-label">Book Name</label>
                            <input type="text" id="book_name" name="book_name" placeholder="Enter Book Name">
                            <span class="error">
                                <?php echo $book_name_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="book_description" class="form-label">Book Description</label>
                            <textarea name="book_description" id="book_description" class="form-input"
                                placeholder="Enter Book Description"></textarea>
                            <span class="error">
                                <?php echo $book_description_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="book_author" class="form-label">Book Author</label>
                            <input type="text" name="book_author" id="book_author" class="form-input"
                                placeholder="Enter Book Author">
                            <span class="error">
                                <?php echo $book_author_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="book_price" class="form-label">Book Price</label>
                            <input type="text" name="book_price" id="book_price" class="form-input"
                                placeholder="Enter Book Price">
                            <span class="error">
                                <?php echo $book_price_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="book_type" class="form-label">Book Type</label>
                            <select id="book_type" name="book_type">BOOK TYPE:
                                <option>Select Book</option>
                                <option value="horror">Horror</option>
                                <option value="kids">Kids</option>
                                <option value="comic">Comic</option>
                                <option value="fiction">Fiction</option>
                                <option value="nonfiction">Non-fiction</option>
                                <option value="academic">Academic/Professional</option>
                                <option value="poetry">Poetry</option>
                                <option value="plays">Plays/Drama</option>
                                <option value="graphicnovels">Graphic Novels</option>
                                <option value="adventure">Adventure</option>
                                <option value="philosophy">Philosophy</option>
                            </select>
                            <span class="error">
                                <?php echo $book_type_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="uploadImage" class="form-label">Book Image</label>
                            <input type="file" id="uploadImage" class="form-input" name="uploadImage">
                            <span class="error">
                                <?php echo $book_image_error; ?>
                            </span>
                        </div>
                        <button type="submit" class="submit-btn" name="submit">Add Book</button>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php">Home</a>
                <a href="Products.php">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
            </nav>
        </div>
        <div id="sub-foot2">
            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape - your destination for literary
                indulgence."</p>
        </div>
        <div class="sub-foot3">
            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>

            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>
        </div>
        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>

</body>

</html>