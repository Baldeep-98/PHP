<?php
class Validation
{
    public static function validatePassword($password)
    {
        // Check if password is at least 6 characters long and contains at least one uppercase letter, one lowercase letter, and one number
        return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/', $password);
    }

    public static function validateEmail($email)
    {
        return filter_var($email, FILTER_VALIDATE_EMAIL);
    }

    public static function validateName($name)
    {
        return preg_match('/^[a-zA-Z\s]+$/', $name);
    }
    public static function validatePhoneNumber($phno)
    {
        return preg_match("/^[0-9]+$/", $phno);
    }
    public static function validatePrice($price)
    {
        return is_numeric($price);
    }
}
?>