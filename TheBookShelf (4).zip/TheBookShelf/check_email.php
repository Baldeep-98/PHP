<?php

include 'db_conn.php';

$dbConnection = new DatabaseConnection();


if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['email'])) {
    $email = $_GET['email'];
    $emailExists = $dbConnection->userExists($email);

    // Return JSON response
    echo json_encode(array('exists' => $emailExists));
    return json_encode(array('exists' => $emailExists));
} else {
    // Invalid request
    http_response_code(400);
    return json_encode(array('message' => 'Invalid request'));
}

?>
