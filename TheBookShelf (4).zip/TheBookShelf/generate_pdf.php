
<?php
session_start();
require_once('db_conn.php');
$dbConnection = new DatabaseConnection();
$conn = $dbConnection->getConnection();

if (isset($_SESSION['email']) && isset($_SESSION['firstname']) && isset($_SESSION['lastname']) &&isset($_SESSION['order_id'])) {
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
    $emailid = $_SESSION['email'];
    $orderId = $_SESSION['order_id'];
}

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

require_once('fpdf/fpdf.php');

class PDF extends FPDF {
    function Header(){
        $this->Image('Imgs/logo_img.png', 10, 10, 30); 
        $this->SetFont('Arial','',18);
        $this->Cell(80);
        $this->Cell(20,30,'Invoice',0,40,'C');
        $this->Cell(20,0,'The Book Shelf',0,40,'C');
        $this->Ln(20);
        $this->SetFont('Arial','',12);
    }
    function footer(){
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->Cell(0,10,'Page '.$this->PageNo().'/{theBookSelf}',0,0,'C');
    }
}
?>
<?php
$pdf = new PDF();
$pdf->AliasNbPages();
if(isset($_SESSION['total_amount'])) {
    $totalAmount = $_SESSION['total_amount'];
} else {
    $totalAmount = 0; // Set a default value if total_amount is not set
}

$orderDetailsQuery = 'SELECT od.order_id, od.emailid, od.full_name, od.contact_number, od.address, od.order_date
FROM order_details od
WHERE od.order_id ="'.$orderId.'"';

$checkoutQuery = 'SELECT od.order_id, od.emailid, od.full_name, od.contact_number, od.address, od.order_date, obd.book_id, bd.book_price, obd.quantity, bd.book_name
FROM order_details od
JOIN order_book_details obd ON od.order_id = obd.order_id
JOIN book_details bd ON obd.book_id = bd.book_id WHERE od.emailid ="'.$emailid.'" AND od.order_id ="'.$orderId.'"';

$orderDetailsResult = mysqli_query($conn, $orderDetailsQuery);
$orderDetailsRow = $orderDetailsResult->fetch_assoc();

$checkoutResult = mysqli_query($conn, $checkoutQuery);

if (!$checkoutResult) {
    die("Query failed: " . mysqli_error($conn));
}
?>
<?php
$pdf=new PDF();
$pdf->AliasNbPages();
$grandTotal = 0; // Initialize grand total
$pdf->AddPage();
    $pdf->SetY(60);
    $pdf->Cell(0,10,'Date: '.date('Y F j'),0,1,'R');
    $pdf->Cell(0,10,'Order Id: '.$orderDetailsRow['order_id'],0,1);
    $pdf->Cell(0,10,'Email: '.$orderDetailsRow['emailid'],0,1);
    $pdf->Cell(0,10,'Full Name: '.$orderDetailsRow['full_name'],0,1);
    $pdf->Cell(0,10,'Contact Number: '.$orderDetailsRow['contact_number'],0,1);
    $pdf->Cell(0,10,'Address: '.$orderDetailsRow['address'],0,1);
    $pdf->Ln(10);
    $pdf->SetFillColor(192,192,192);
    $pdf->Cell(70, 10, 'Book Name', 1, 0, 'C', true);
    $pdf->Cell(20, 10, 'Quantity', 1, 0, 'C', true);
    $pdf->Cell(30,10,'Unit Price ($)',1,0,'C',true);
    $pdf->Cell(30,10,'Total Price ($)',1,0,'C',true); 
    $pdf->Cell(30,10,'Order Date',1,0,'C',true); 
    $pdf->Ln();
while ($checkoutData = mysqli_fetch_assoc($checkoutResult)) {
    $pdf->Cell(70,10,$checkoutData['book_name'],1);
    $pdf->Cell(20,10,$checkoutData['quantity'],1);
    $pdf->Cell(30,10,$checkoutData['book_price'],1);
    $totalPrice = $checkoutData['quantity'] * $checkoutData['book_price']; 
    $pdf->Cell(30,10,$totalPrice,1);
    $pdf->Cell(30,10,$checkoutData['order_date'],1);
    $pdf->Ln(10);
    $grandTotal += $totalPrice;
}
$pdf->Ln(10);
if ($grandTotal == 0) {
    $pdf->Cell(0,10,'Grand Total: $' . number_format($totalAmount, 2),0,1,'R');
} else {
    $pdf->Cell(0,10,'Total Amount: $' . number_format($grandTotal, 2),0,1,'R');
}

// Output the PDF
$pdf->Output();
?>
