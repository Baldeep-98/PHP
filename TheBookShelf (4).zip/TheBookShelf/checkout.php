<?php
include 'db_conn.php';
include 'validation.php';
session_start();
$dbConnection = new DatabaseConnection();
//setting firstname and lastname from Session
if (isset($_SESSION['email']) && isset($_SESSION['firstname']) && isset($_SESSION['lastname'])) {
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
    $emailid = $_SESSION['email'];
}

//Valudations for Checkout Form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = [];

    if (empty($_POST['full_name'])) {
        $errors['full_name'] = "Name is required";
    } else {
        $full_name = $_POST["full_name"];
        if (!Validation::validateName($full_name)) {
            $errors['full_name'] = "Enter valid Name";
            $full_name = '';
        }
    }

    if (empty($_POST['contact_number'])) {
        $errors['contact_number'] = "Contact Number is required";
    } else {
        $contact_number = $_POST["contact_number"];
        if (!Validation::validatePhoneNumber($contact_number)) {
            $errors['contact_number'] = "Enter a valid contact Number";
            $contact_number = '';
        }
    }

    if (empty($_POST['address'])) {
        $errors['address'] = "Address is required";
    } else {
        $address = $_POST['address'];
    }

    if (empty($_POST['city'])) {
        $errors['city'] = "City is required";
    } else {
        $city = $_POST['city'];
    }

    if (empty($_POST['province'])) {
        $errors['province'] = "Province is required";
    } else {
        $province = $_POST['province'];
    }

    if (empty($_POST['postalcode'])) {
        $errors['postalcode'] = "Postal code is required";
    } else {
        $postalcode = $_POST['postalcode'];
    }

    // If there are no errors, insert data into the database
    if (empty($errors)) {
        // Call insertCheckOut method to insert data
        $insertResult = $dbConnection->insertOrderDetails($emailid, $full_name, $contact_number, $address, $city, $province, $postalcode);

        if ($insertResult) {
            // Get the order ID
            $order_id = $insertResult;

            // Iterate through cart items and insert into order_books_details table
            foreach ($_SESSION['cart'] as $cartItem) {
                $book_id = $cartItem['id'];
                $quantity = $cartItem['quantity'];

                // Insert into order_books_details table
                $insertBookResult = $dbConnection->insertOrderBookDetails($order_id, $book_id, $quantity);

                // Check if insertion was successful
                if (!$insertBookResult) {
                    // Handle the failure (e.g., log, display error message)
                    echo "Failed to insert order book details.";
                }
            }
            unset($_SESSION['cart']);
            $_SESSION['order_id'] = $order_id;
            header('Location:order_confirmation.php');
        } else {
            // Handle order insertion failure (e.g., log, display error message)
            echo "Failed to insert order details.";
        }
        // You can handle $insertResult as needed (e.g., display success message or handle errors)
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Contact Us - Page</title>
</head>

<body>

    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php">Home</a>
            <a href="Products.php">Books</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>

            <?php
            if (!isset($_SESSION['email'])) {
                ?>
                <a href="login.php">Login</a>
                <?php
            } else { ?>
                <a href="cart.php">Cart</a>
                <a href="logout.php">Logout</a>
            </div>

            <?php
            echo "<div class='profile-name-container'> <div href='#' class='profile-name'>
                    <img src ='Imgs/user.png' alt='profile icon' class='profile-icon'/>
                    <span> 
                        $lastname, $firstname 
                    </span>
                </div>";
            }
            ?>
    </nav>

    <main class="checkout-container">
        <h2>Enter Shipping Details</h2>
        <div class="checkout-card-container">
            <div class="product-card">

                <h3 class="checkout-total-amount">
                    <?php
                    $totalAmount = 0;
                    foreach ($_SESSION['cart'] as $cartItem) {
                        // Calculate total price for each item and add to the total amount
                        $totalAmount += $cartItem['total_price'];
                    }
                    echo 'Total Amount: $' . number_format($totalAmount, 2); // Display the total amount
                    ?>
                </h3>

                <form action="checkout.php" id="checkout_form" method="POST">
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" id="full_name" name="full_name"
                            value="<?php echo isset($full_name) ? $full_name : ''; ?>">
                        <span class="error">
                            <?php echo isset($errors['full_name']) ? $errors['full_name'] : ''; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label for="contact_number">Phone Number</label>
                        <input type="text" id="contact_number" name="contact_number"
                            value="<?php echo isset($contact_number) ? $contact_number : ''; ?>">
                        <span class="error">
                            <?php echo isset($errors['contact_number']) ? $errors['contact_number'] : ''; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label for="address">Address</label>
                        <input type="text" id="address" name="address"
                            value="<?php echo isset($address) ? $address : ''; ?>">
                        <span class="error">
                            <?php echo isset($errors['address']) ? $errors['address'] : ''; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label for="city">City</label>
                        <input type="text" id="city" name="city" value="<?php echo isset($city) ? $city : ''; ?>">
                        <span class="error">
                            <?php echo isset($errors['city']) ? $errors['city'] : ''; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label for="province">Province</label>
                        <select id="province" name="province">
                            <option value="">Select Province</option>
                            <option value="Alberta">Alberta</option>
                            <option value="British Columbia">British Columbia</option>
                            <option value="Manitoba">Manitoba</option>
                            <option value="New Brunswick">New Brunswick</option>
                            <option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
                            <option value="Nova Scotia">Nova Scotia</option>
                            <option value="Ontario">Ontario</option>
                            <option value="Prince Edward Island">Prince Edward Island</option>
                            <option value="Quebec">Quebec</option>
                            <option value="Saskatchewan">Saskatchewan</option>
                            <option value="Northwest Territories">Northwest Territories</option>
                            <option value="Nunavut">Nunavut</option>
                            <option value="Yukon">Yukon</option>
                        </select>
                        <span class="error">
                            <?php echo isset($errors['province']) ? $errors['province'] : ''; ?>
                        </span>
                    </div>
                    <div class="form-group">
                        <label for="postalcode">Postal Code</label>
                        <input type="text" id="postalcode" name="postalcode"
                            value="<?php echo isset($postalcode) ? $postalcode : ''; ?>">
                        <span class="error">
                            <?php echo isset($errors['postalcode']) ? $errors['postalcode'] : ''; ?>
                        </span>
                    </div>
                    <button type="submit">Place Order</button>
                </form>
            </div>
        </div>

    </main>

    <footer>
        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php">Home</a>
                <a href="Products.php">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
            </nav>
        </div>

        <div id="sub-foot2">

            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape – your destination for literary
                indulgence."</p>

        </div>

        <div class="sub-foot3">

            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>

            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>

        </div>

        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>


</body>

</html>