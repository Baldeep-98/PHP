<?php
session_start();
include 'db_conn.php';
include 'validation.php';
//setting firstname and lastname from Session
if (isset($_SESSION['email']) && isset($_SESSION['firstname']) && isset($_SESSION['lastname'])) {
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
}
// Validations for Contact Us Form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = [];

    if (empty($_POST["first_name"])) {
        $errors['first_name'] = "First Name is required";
    } else {
        $first_name = $_POST["first_name"];
        if (!Validation::validateName($first_name)) {
            $errors['first_name'] = "Enter valid First Name";
            $first_name = '';
        }
    }
    if (empty($_POST["last_name"])) {
        $errors['last_name'] = "Last Name is required";
    } else {
        $last_name = $_POST["last_name"];
        if (!Validation::validateName($last_name)) {
            $errors['last_name'] = "Enter valid Last Name";
            $last_name = '';
        }
    }
    if (empty($_POST["email"])) {
        $errors['email'] = "Email is required";
    } else {
        $email = $_POST["email"];
        if (!Validation::validateEmail($email)) {
            $errors['email'] = "Invalid email format";
            $email = '';
        }
    }

    if (empty($_POST['phno'])) {
        $errors['phno'] = "Phone Number is required";
    } else {
        $phno = $_POST["phno"];
        if (!Validation::validatePhoneNumber($phno)) {
            $errors['phno'] = "Invalid Phone Number.";
            $phno = '';
        }
    }

    if (!empty($_POST['message'])) {
        $message = $_POST['message'];
    } else {
        $errors['message'] = "Message is required";
    }
    if (!empty($_POST['province'])) {
        $province = $_POST['province'];
    } else {
        $errors['province'] = "Province is required";
    }

    if (empty($errors)) {

        $dbConnection = new DatabaseConnection();
        $result = $dbConnection->insertContactUsDetails($first_name, $last_name, $email, $phno, $province, $message);
        if ($result) {
            echo '<script>alert("Your message has been received. Our team will get back to you within 24 hours.");</script>';
            echo '<script>window.setTimeout(function(){ window.location.href = "index.php"; }, 1000);</script>';
            exit;
        } else {
            echo "Some error occurred in saving the data";
        }

    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <title>Contact Us - Page</title>
</head>

<body>
    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php">Home</a>
            <a href="Products.php">Books</a>
            <a href="about.php">About Us</a>
            <a href="contact.php" class="active">Contact Us</a>

            <?php
            if (!isset($_SESSION['email'])) {
                ?>
                <a href="login.php">Login</a>
                <?php
            } else {
                ?>
                <a href="cart.php">Cart</a>
                <a href="logout.php">Logout</a>
            </div>

            <?php
            echo "<div class='profile-name-container'> <div href='#' class='profile-name'>
                    <img src ='Imgs/user.png' alt='profile icon' class='profile-icon'/>
                    <span> 
                        $lastname, $firstname 
                    </span>
                </div>";
            }
            ?>
    </nav>

    <main>

        <div class="container">

            <div class="container2">
                <div class="contact-card">
                    <div class="card-content">
                        <h2>
                            Contact Us
                        </h2>
                        <label>
                            <span class="material-symbols-outlined">
                                mail
                            </span>&nbsp; thebookshelf@gmail.com</label>
                        <label>
                            <span class="material-symbols-outlined">
                                call
                            </span>&nbsp; +1-786-909-3457</label>
                    </div>
                </div>

                <div class="contact-card">
                    <div class="card-content">
                        <h2>Visit us</h2>
                        <label>
                            <span class="material-symbols-outlined">
                                location_on
                            </span>&nbsp;123 Main St, Kitchener, Ontario</label>
                        <label> &nbsp; &nbsp; N2P0J3</label>
                    </div>
                </div>

                <div class="contact-card">
                    <div class="card-content">
                        <h2>Business Hours</h2>
                        <label>
                            <span class="material-symbols-outlined">
                                schedule
                            </span>&nbsp;Mon-Fri 10:00 A.M. to 5:00 P.M.</label>
                        <label>&nbsp; &nbsp;Sat-Sun Closed</label>
                    </div>
                </div>

            </div>
            <div class="form-card">
                <div class="card-content">
                    <h2 class="contact-form-heading">Get In Touch With Us!</h2>
                    <form class="form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" id="contact_form">
                        <div class="contact-info">
                            <div class="contact-user-name">
                                <div class="first-name-section">
                                    <label for="first_name" class="label-hidden">First Name</label>
                                    <input type="text" name="first_name" id="first_name" placeholder="First Name"
                                        value="<?php echo isset($first_name) ? $first_name : ''; ?>">
                                    <span class="error">
                                        <?php echo isset($errors['first_name']) ? $errors['first_name'] : ''; ?>
                                    </span>
                                </div>

                                <div class="last-name-section">
                                    <label for="last_name" class="label-hidden">Last Name</label>
                                    <input type="text" name="last_name" id="last_name" placeholder="Last Name"
                                        value="<?php echo isset($last_name) ? $last_name : ''; ?>" >
                                    <span class="error">
                                        <?php echo isset($errors['last_name']) ? $errors['last_name'] : ''; ?>
                                    </span>
                                </div>

                            </div>
                            <label for="email" class="label-hidden">Email</label>
                            <input type="text" name="email" id="email" placeholder="Email"
                                value="<?php echo isset($email) ? $email : ''; ?>">
                            <span class="error">
                                <?php echo isset($errors['email']) ? $errors['email'] : ''; ?>
                            </span>
                            <label for="phno" class="label-hidden">Phone Number</label>
                            <input type="text" name="phno" id="phno" placeholder="Phone Number"
                                value="<?php echo isset($phno) ? $phno : ''; ?>">
                            <span class="error">
                                <?php echo isset($errors['phno']) ? $errors['phno'] : ''; ?>
                            </span>
                            <label for="province" class="label-hidden">Province</label>
                            <select name="province" id="province">
                                <option value="">Select Province</option>
                                <option value="Alberta">Alberta</option>
                                <option value="British Columbia">British Columbia</option>
                                <option value="Manitoba">Manitoba</option>
                                <option value="New Brunswick">New Brunswick</option>
                                <option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
                                <option value="Nova Scotia">Nova Scotia</option>
                                <option value="Ontario">Ontario</option>
                                <option value="Prince Edward Island">Prince Edward Island</option>
                                <option value="Quebec">Quebec</option>
                                <option value="Saskatchewan">Saskatchewan</option>
                                <option value="Northwest Territories">Northwest Territories</option>
                                <option value="Nunavut">Nunavut</option>
                                <option value="Yukon">Yukon</option>
                            </select>
                            <span class="error">
                                <?php echo isset($errors['province']) ? $errors['province'] : ''; ?>
                            </span>
                            <label for="message" class="label-hidden">Message</label>
                            <textarea name="message" id="message" placeholder="Enter Your Message" rows="4"></textarea>
                            <span class="error">
                                <?php echo isset($errors['message']) ? $errors['message'] : ''; ?>
                            </span>
                            <button type="submit" class="sendsubmit">Send Message</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </main>

    <footer>

        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php">Home</a>
                <a href="Products.php">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php" class="active">Contact Us</a>
            </nav>

        </div>

        <div id="sub-foot2">

            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape – your destination for literary
                indulgence."</p>

        </div>

        <div class="sub-foot3">

            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>

            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>

        </div>

        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>
</body>

</html>