<?php
session_start();
include 'db_conn.php';
//setting firstname and lastname from Session
if (isset($_SESSION['email']) && isset($_SESSION['firstname']) && isset($_SESSION['lastname'])) {
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
}

// Initialize cart if not already set
if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_book_id'])) {
    $bookIdToDelete = $_POST['delete_book_id'];
    $index = array_search($bookIdToDelete, array_column($_SESSION['cart'], 'id'));
    if ($index !== false) {
        array_splice($_SESSION['cart'], $index, 1); // Remove the book from the cart array
    } else {
        echo "Failed to delete book from the cart.";
    }
}
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['quantity']) && isset($_POST['total_price'])) {
    $bookIdToUpdate = $_POST['id'];
    $newQuantity = $_POST['quantity'];
    $newPrice = $_POST['total_price'];
    foreach ($_SESSION['cart'] as &$cartItem) {
        if ($cartItem['id'] == $bookIdToUpdate) {
            $cartItem['quantity'] = $newQuantity;
            $cartItem['total_price'] = $newPrice;
            break;
        }
    }
    unset($cartItem); // Unset reference
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>The Book Shelf</title>
    <script>
        function updateQuantity(input, increment) {
            var quantityInput = input.parentElement.querySelector('input[name="quantity"]');
            var quantity = parseInt(quantityInput.value);
            var bookIdInput = input.parentElement.querySelector('input[name="id"]');
            var bookId = parseInt(bookIdInput.value);
            if (increment) {
                quantity++;
            } else {
                if (quantity > 1) {
                    quantity--;
                }
            }
            quantityInput.value = quantity;
            var priceElement = input.parentElement.parentElement.parentElement.querySelector('.price');
            var price = parseFloat(input.parentElement.querySelector('input[name="price"]').value);
            console.log(price);
            priceElement.textContent = (price * quantity).toFixed(2);

            var total_price = (price * quantity).toFixed(2);
            console.log(total_price);
            // Send asynchronous request to update quantity in session
            var xhr = new XMLHttpRequest();
            xhr.open("POST", window.location.href, true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function () {
                if (xhr.readyState === XMLHttpRequest.DONE && xhr.status === 200) {
                    console.log("test");
                }
            };
            xhr.send("quantity=true&id=" + bookId + "&quantity=" + quantity + "&total_price=" + total_price);
        }
    </script>

</head>

<body>
    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php">Home</a>
            <a href="Products.php">Books</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>

            <?php
            if (!isset($_SESSION['email'])) {
                ?>
                <a href="login.php">Login</a>
                <?php
            } else {
                ?>
                <a href="cart.php" class="active">Cart</a>
                <a href="logout.php">Logout</a>
            </div>

            <?php
            echo "<div class='profile-name-container'> <div href='#' class='profile-name'>
                    <img src ='Imgs/user.png' alt='profile icon' class='profile-icon'/>
                    <span> 
                        $lastname, $firstname 
                    </span>
                </div>";
            }
            ?>
    </nav>

    <main class="cart-container">
        <h2 class="products-heading">CART</h2>
        <div class="cart-products-container">
            <?php
            // Show output 
            foreach ($_SESSION['cart'] as $cartItem) {
                // Construct the image path
                $image_path = 'Imgs/uploads/' . $cartItem['uploadImage'];
                ?>
                <div class="product-card-container">
                    <div class="product-card">
                        <div class="prod-img-container">
                            <img src="<?php echo $image_path; ?>" alt="<?php echo $cartItem['name']; ?>"
                                class="product-image">
                        </div>
                        <h4>
                            <?php echo $cartItem['name']; ?>
                        </h4>
                        <p>
                            By <?php echo $cartItem['author']; ?>
                        </p>

                        <form method="post">
                            <div class="price-quant-container">
                                <p>
                                    <?php echo '$' . $cartItem['price']; ?>
                                </p>
                                <div class="quantity">
                                    <button type="button" onclick="updateQuantity(this, true)">+</button>
                                    <input type="text" hidden name="price" value="<?php echo $cartItem['price']; ?>">
                                    <input type="text" hidden name="id" value="<?php echo $cartItem['id']; ?>">

                                    <div class="quantity-text">
                                        <input type="text" name="quantity" value="<?php echo $cartItem['quantity']; ?>">
                                    </div>
                                    <button type="button" onclick="updateQuantity(this, false)">-</button>
                                </div>
                            </div>

                            <p class="total-amt">Total Price $: <span class="price">
                                    <?php echo $cartItem['total_price']; ?>
                                </span>
                            </p>

                            <input type="hidden" name="delete_book_id" value="<?php echo $cartItem['id']; ?>">
                            <button type="submit" class="product-card button-link">Delete</button>
                        </form>
                    </div>
                </div>
                <?php
            }
            ?>

        </div>
        <?php if (count($_SESSION['cart']) > 0): ?>
            <form action="checkout.php" method="GET" class="checkout-form">
                <input type="submit" value="Checkout" class="checkout-btn" />
            </form>
        <?php else: ?>
            <div class="empty-cart-message">
                <img src="Imgs\Empty-cart.png" alt="Empty Cart image">
                <p>Oops! Your Shopping Cart is empty.</p>
                <a href="products.php"><button type="button"> Shop Now</button></a>
            </div>
        <?php endif; ?>

        </div>
    </main>
    <footer>
        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php">Home</a>
                <a href="Products.php">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
            </nav>
        </div>
        <div id="sub-foot2">

            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape – your destination for literary
                indulgence."</p>
        </div>
        <div class="sub-foot3">
            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>
            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>
        </div>
        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>
</body>

</html>