<?php
include 'db_conn.php';
include 'validation.php';
session_start();
// setting firstname and lastname from session
if (isset($_SESSION['email']) && isset($_SESSION['firstname']) && isset($_SESSION['lastname'])) {
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
}
$book_name_error = $book_description_error = $book_price_error = $book_author_error = $book_image_error = $book_type_error = $book_uploadImagename_error = "";

$dbConnection = new DatabaseConnection();
$book_id = "";
$book_name = "";
$book_description = "";
$book_price = "";
$book_type = "";
$book_author = "";
$book_uploadImagename = "";


if (isset($dbConnection) && array_key_exists('bookid', $_GET)) {

    $bookid = $_GET['bookid'];

    $bookDetail = $dbConnection->getBookDetailsById($bookid);

    if ($bookDetail) {
        $book_id = $bookDetail['book_id'];
        $book_name = $bookDetail['book_name'];
        $book_description = $bookDetail['book_description'];
        $book_price = $bookDetail['book_price'];
        $book_type = $bookDetail['book_type'];
        $book_author = $bookDetail['book_author'];
        $book_uploadImagename = $bookDetail['uploadImage'];
    } else {
        echo 'console.log("Error in fetching the book data by ID.");</script>';
    }

}



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $book_name_input= !empty($_POST['book_name']) ? htmlspecialchars($_POST['book_name'], ENT_QUOTES, 'UTF-8') : '';
    $book_description_input = !empty($_POST['book_description']) ? htmlspecialchars($_POST['book_description'], ENT_QUOTES, 'UTF-8') : '';
    $book_price_input = !empty($_POST['book_price']) ? $_POST['book_price'] : '';
    $book_author_input = !empty($_POST['book_author']) ? htmlspecialchars($_POST['book_author'], ENT_QUOTES, 'UTF-8') : '';    

    if (!empty($_POST['book_id'])) {
        $book_id = $_POST['book_id'];
    }

    
    if (!empty($book_name_input)) {
        
        if (strlen(trim($book_name_input)) <= 0) {
            $book_name_error = "Enter valid Book author";
            $book_name_input = '';
        }
        else {
            $book_name = $book_name_input;
        }
    } else {
        $book_name_error = "Book Name is required";
    }


    if (!empty($book_description_input)) {

        if (strlen(trim($book_description_input)) <= 0) {
            $book_description_error = "Enter valid Book description";
            $book_description_input = '';
        }
        else {
            $book_description = $book_description_input;
        } 
    } else {
        $book_description_error = "Book description is required.";
    }



    if (!empty($book_price_input)) {

        if (!Validation::validatePrice($book_price_input)) {
            $book_price_error = "Enter price in valid format";
            $book_price_input = '';
        }
        else {
            $book_price = $book_price_input;
        }
    } else {
        $book_price_error = "Book price is required.";
    }


    if (!empty($book_author_input)) {
        if (strlen(trim($book_author_input)) <= 0) {
            $book_author_error = "Enter valid Book description";
            $book_author_input = '';
        }
        else {
            $book_author = $book_author_input;
        }
        
    } else {
        $book_author_error = "Book author is required.";
    }


    if (!empty($_POST['book_type']) && $_POST['book_type'] !== "Select Book") {
        $book_type = $_POST['book_type'];
    } else {
        $book_type_error = "Please select a valid book type.";
    }

    if (empty($_FILES['uploadImage']['name'])) {
        $book_uploadImagename = $_POST['uploadImagename'];
        $book_uploadImagename_error = "Please select a valid book type.";
    } else {
        $book_uploadImage = $_FILES['uploadImage']['name'];
        echo '<script>console.log("Book Book Book.");</script>';
        echo '<script>console.log("Book Book Book.' . empty($book_uploadImagename_error) . ');</script>';

    }


    if (empty($book_name_error) && empty($book_description_error) && empty($book_author_error) && empty($book_price_error) && empty($book_type_error) && empty($book_uploadImagename_error)) {

        if (!empty($_FILES['uploadImage']['name'])) {

            $uploadOk = 1;
            $uploadImage = $_FILES['uploadImage']['name'];

            $target_dir = "Imgs/uploads/";
            $target_file = $target_dir . basename($_FILES["uploadImage"]["name"]);
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            // Check if image file is a actual image or fake image
            if (isset($_POST["submit"])) {
                $check = getimagesize($_FILES["uploadImage"]["tmp_name"]);
                if ($check !== false) {
                    $uploadOk = 1;
                } else {
                    $book_image_error = 'File is not an image.';
                    $uploadOk = 0;
                }
            }

            // Check file size
            if ($_FILES["uploadImage"]["size"] > 500000) {
                $book_image_error = 'Sorry, your file is too large.';
                $uploadOk = 0;
            }

            // Allow certain file formats
            if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                $book_image_error = 'Sorry, only JPG, JPEG, PNG & GIF files are allowed.';
                $uploadOk = 0;
            }

            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 1) {
                if (move_uploaded_file($_FILES["uploadImage"]["tmp_name"], $target_file)) {
                    echo "<script> console.log('The file " . htmlspecialchars(basename($_FILES["uploadImage"]["name"])) . " has been uploaded.') </script>";
                } else {
                    $book_image_error = 'Sorry, there was an error uploading your file.';
                }
            }

            if ($uploadOk == 1) {

                $result = $dbConnection->updateBookById($book_id, $book_name, $book_description, $book_price, $book_author, $book_type, $uploadImage);

                if (isset($result)) {
                    echo '<script>alert("Book details have been successfully updated.");</script>';
                    header("Location: products.php");
                }
            }
        }
    } else if ((empty($book_name_error) && empty($book_description_error) && empty($book_author_error) && empty($book_price_error) && empty($book_type_error) && !empty($book_uploadImagename_error))) {

        $result = $dbConnection->updateBookById($book_id, $book_name, $book_description, $book_price, $book_author, $book_type, $book_uploadImagename);

        if (isset($result)) {
            echo '<script>alert("Book details have been successfully updated.");</script>';
            header("Location: products.php");
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Update Book - Page</title>
</head>

<body>

    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php" class="active">Home</a>
            <a href="Products.php">Books</a>

            <?php
            if (!isset($_SESSION['email'])) {
                ?>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
                <a href="login.php">Login</a>
                <?php
            } else { ?>
                <a href="add_book.php" >Add Book</a>
                <a href="logout.php">Logout</a>
            </div>

            <?php
            echo "<div class='profile-name-container'> <div href='#' class='profile-name'>
                    <img src ='Imgs/user.png' alt='profile icon' class='profile-icon'/>
                    <span> 
                        $lastname, $firstname 
                    </span>
                </div>";
            }
            ?>
    </nav>

    <main>
        <div class="checkout-container">
            <h1>Update Book</h1>
            <div class="checkout-card-container">
                <div class="product-card">
                    <form class="adminform" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" id="admin_form"
                        enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="book_id" class="form-label">Book ID</label>
                            <input type="text" name="book_id" id="book_id" class="form-input"
                                value="<?php echo $book_id ?>" readonly>
                        </div>
                        <div class="form-group">
                            <label for="book_name" class="form-label">Book Name</label>
                            <input type="text" name="book_name" id="book_name" class="form-input"
                                placeholder="Enter Book Name"
                                value="<?php echo isset($book_name) ? $book_name : ''; ?>">
                            <span class="error">
                                <?php echo $book_name_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="book_description" class="form-label">Book Description</label>
                            <textarea name="book_description" id="book_description" class="form-input"
                                placeholder="Enter Book Description"><?php echo isset($book_description) ? $book_description : ''; ?></textarea>
                            <span class="error">
                                <?php echo $book_description_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="book_author" class="form-label">Book Author</label>
                            <input type="text" name="book_author" id="book_author" class="form-input"
                                placeholder="Enter Book Author"
                                value="<?php echo isset($book_author) ? $book_author : ''; ?>">
                            <span class="error">
                                <?php echo $book_author_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="book_price" class="form-label">Book Price</label>
                            <input type="text" name="book_price" id="book_price" class="form-input"
                                placeholder="Enter Book Price"
                                value="<?php echo isset($book_price) ? $book_price : ''; ?>">
                            <span class="error">
                                <?php echo $book_price_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="book_type" class="form-label">Book Type</label>
                            <select id="book_type" name="book_type"
                                value="<?php echo isset($book_type) ? $book_type : ''; ?>">BOOK TYPE:
                                <option>Select Book</option>
                                <option value="horror" <?php echo (isset($book_type) && $book_type == "horror") ? "Selected" : ""; ?>>Horror</option>
                                <option value="kids" <?php echo (isset($book_type) && $book_type == "kids") ? "Selected" : ""; ?>>Kids</option>
                                <option value="comic" <?php echo (isset($book_type) && $book_type == "comic") ? "Selected" : ""; ?>>Comic</option>
                                <option value="fiction" <?php echo (isset($book_type) && $book_type == "fiction") ? "Selected" : ""; ?>>Fiction</option>
                                <option value="nonfiction" <?php echo (isset($book_type) && $book_type == "nonfiction") ? "Selected" : ""; ?>>Non-fiction</option>
                                <option value="academic" <?php echo (isset($book_type) && $book_type == "academic") ? "Selected" : ""; ?>>Academic/Professional</option>
                                <option value="poetry" <?php echo (isset($book_type) && $book_type == "poetry") ? "Selected" : ""; ?>>Poetry</option>
                                <option value="plays" <?php echo (isset($book_type) && $book_type == "plays") ? "Selected" : ""; ?>>Plays/Drama</option>
                                <option value="graphicnovels" <?php echo (isset($book_type) && $book_type == "graphicnovels") ? "Selected" : ""; ?>>Graphic Novels</option>
                                <option value="adventure" <?php echo (isset($book_type) && $book_type == "adventure") ? "Selected" : ""; ?>>Adventure</option>
                                <option value="philosophy" <?php echo (isset($book_type) && $book_type == "philosophy") ? "Selected" : ""; ?>>Philosophy</option>
                            </select>
                            <span class="error">
                                <?php echo $book_type_error; ?>
                            </span>
                        </div>
                        <div class="form-group">
                            <label for="uploadImage" class="form-label">Update Book Image</label>
                            <input type="file" id="uploadImage" class="form-input" name="uploadImage">
                            <span class="error">
                                <?php echo $book_image_error; ?>
                            </span>
                        </div>

                        <label for="uploadImagename" class="form-label">Current Book Image</label>
                        <input type="hidden" id="uploadImagename" name="uploadImagename"
                            value="<?php echo isset($book_uploadImagename) ? $book_uploadImagename : ''; ?>">
                        <div class="prod-img-container">
                            <img src="Imgs/uploads/<?php echo isset($book_uploadImagename) ? $book_uploadImagename : ''; ?>"
                                alt="<?php echo $book_uploadImagename . ' image'; ?>" class="product-image">
                        </div><br /><br />
                        <button type="submit" class="submit-btn" name="submit">Update Book</button>
                    </form>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php">Home</a>
                <a href="Products.php">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
            </nav>
        </div>
        <div id="sub-foot2">
            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape - your destination for literary
                indulgence."</p>
        </div>
        <div class="sub-foot3">
            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>

            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>
        </div>
        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>

</body>

</html>