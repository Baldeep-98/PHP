<?php
include 'db_conn.php';
session_start();

$errors = array(); // Initialize an array to store errors
$dbConnection = new DatabaseConnection();

//validations for login form 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = !empty($_POST["email"]) ? htmlspecialchars($_POST["email"], ENT_QUOTES, 'UTF-8') : '';
    if (empty($_POST["email"])) {
        $errors['email'] = "Email is required";
    }
    $password = !empty($_POST["password"]) ? htmlspecialchars($_POST["password"], ENT_QUOTES, 'UTF-8') : ''; //sql injection
    if (empty($_POST["password"])) {
        $errors['password'] = "Password is required";
    }
    if (empty($errors)) {
        $email = $_POST["email"];
        $password = $_POST["password"];

        $dbConnection = new DatabaseConnection();

        if ($dbConnection->isAdmin($email, $password)) {
            $_SESSION['email'] = $email;
            $_SESSION['firstname'] = 'Admin';
            $_SESSION['lastname'] = 'Admin';
            header("Location: products.php");
            exit;
        } else {
            if ($dbConnection->loginUser($email, $password)) {
                $userDetails = $dbConnection->getUserDetails($email);
                $_SESSION['email'] = $email;
                $_SESSION['is_admin'] = false;
                $_SESSION['firstname'] = $userDetails['firstname'];
                $_SESSION['lastname'] = $userDetails['lastname'];
                header("Location: products.php");
                exit;
            } else {
                $errors['invalid_email_password'] = "Please provide valid email and password";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>The Book Shelf</title>
</head>

<body>

    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php">Home</a>
            <a href="Products.php">Books</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>

            <?php
            if (!isset($_SESSION['email'])) {
                ?>
                <a href="login.php" class="active">Login</a>
                <?php
            } else {
                if (!$_SESSION['is_admin']) {
                    ?>
                    <a href="cart.php">Cart</a>
                    <?php
                } else { ?>
                    <a href="add_book.php">Add Book</a>
                    <?php
                }
                ?>
                <a href="logout.php">Logout</a>
            </div>

            <?php
            echo "<div class='profile-name-container'> <div href='#' class='profile-name'>
                    <img src ='Imgs/user.png' alt='profile icon' class='profile-icon'/>
                    <span> 
                        $lastname, $firstname 
                    </span>
                </div>";
            }
            ?>
    </nav>

    <br>
    <main>
        <h1>Login</h1>
        <form id="login_form" action="login.php" method="POST">
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" id="email" name="email">
                <span class="error">
                    <?php echo isset($errors['email']) ? $errors['email'] : ''; ?>
                </span>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password">
                <span class="error">
                    <?php echo isset($errors['password']) ? $errors['password'] : ''; ?>
                </span>
            </div>
            <div class="error-message">
                <?php if (isset($errors['invalid_email_password'])) { ?>
                    <p class="error">
                        <?php echo $errors['invalid_email_password'] ?>
                    </p>
                <?php } ?>
            </div>
            <button type="submit">Login</button>
            <p>Not registered yet? <a href="register.php">Register here</a></p>
        </form>

    </main>
    <footer>
        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php">Home</a>
                <a href="Products.php">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
            </nav>
        </div>
        <div id="sub-foot2">

            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape – your destination for literary
                indulgence."</p>
        </div>
        <div class="sub-foot3">
            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>
            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>
        </div>
        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>
</body>

</html>