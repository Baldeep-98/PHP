<?php
include 'db_conn.php';
include 'validation.php';
session_start();

$errors = array(); // Initialize an array to store errors
$dbConnection = new DatabaseConnection();



function checkEmailExistenceAPI($email) {
    echo "<script>console.log('in API method') </script>";

    $currentFolderPath = __DIR__;
    $relativePath = str_replace('\\', '/', $currentFolderPath);
    $relativePath = str_replace($_SERVER['DOCUMENT_ROOT'], '', $relativePath);
    $relativePath = str_replace(' ', '%20', $relativePath);    

    $api_url = 'http://localhost/'.$relativePath.'/check_email.php?email=' . urlencode($email);
    $response = file_get_contents($api_url);
    $result = json_decode($response,true);
    return isset($result['exists']) ? $result['exists'] : false;
}

// validations for Register form
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["firstname"])) {
        $errors['firstname'] = "First Name is required";
    } else {
        $firstname = $_POST["firstname"];
        if (!Validation::validateName($firstname)) {
            $errors['firstname'] = "Enter valid First Name";
        }
    }
    if (empty($_POST["lastname"])) {
        $errors['lastname'] = "Last Name is required";
    } else {
        $lastname = $_POST["lastname"];
        if (!Validation::validateName($lastname)) {
            $errors['lastname'] = "Enter valid Last Name";
        }
    }
    if (empty($_POST["email"])) {
        $errors['email'] = "Email is required";
    } else {
        $email = $_POST["email"];
        if (!Validation::validateEmail($email)) {
            $errors['email'] = "Invalid email format";
        } else {
            if (checkEmailExistenceAPI($email)) {
                $errors['email'] = "Email is already registered";
            }
        }
    }

    if (empty($_POST["password"])) {
        $errors['password'] = "Password is required";
    } else {
        $password = $_POST["password"];
        if (!Validation::validatePassword($password)) {
            $errors['password'] = "Password must be at least 6 characters long and contain at least one uppercase letter, one lowercase letter, and one number";
        }
    }

    if (empty($errors)) {
        if ($dbConnection->registerUser($email, $password, $firstname, $lastname)) {
            $_SESSION['email'] = $email;
            $_SESSION['is_admin'] = false;
            if ($dbConnection->isAdmin($email, $password)) {
                $_SESSION['is_admin'] = true;
            }
            $_SESSION['firstname'] = $firstname;
            $_SESSION['lastname'] = $lastname;
            header("Location: products.php");
            exit;
        } else {
            $errors['error_message'] = "Failed to Register User";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>The Book Shelf</title>
</head>

<body>

    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php">Home</a>
            <a href="products.php">Books</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact Us</a>
            <a href="login.php" class="active">Login</a>
        </div>
    </nav>
    <br>
    <main>
        <h1>Register</h1>
        <form id="register_form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="form-group">
                <label for="firstname">First Name:</label>
                <input type="text" id="firstname" name="firstname"
                    value="<?php echo isset($firstname) ? $firstname : ''; ?>">
                <span class="error">
                    <?php echo isset($errors['firstname']) ? $errors['firstname'] : ''; ?>
                </span>
            </div>
            <div class="form-group">
                <label for="lastname">Last Name:</label>
                <input type="text" id="lastname" name="lastname"
                    value="<?php echo isset($lastname) ? $lastname : ''; ?>">
                <span class="error">
                    <?php echo isset($errors['lastname']) ? $errors['lastname'] : ''; ?>
                </span>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="text" id="email" name="email" value="<?php echo isset($email) ? $email : ''; ?>">
                <span class="error">
                    <?php echo isset($errors['email']) ? $errors['email'] : ''; ?>
                </span>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password"
                    value="<?php echo isset($password) ? $password : ''; ?>">
                <span class="error">
                    <?php echo isset($errors['password']) ? $errors['password'] : ''; ?>
                </span>
            </div>
            <button type="submit">Register</button>
            <p>Already have an account? <a href="login.php">Login here</a></p>
        </form>
    </main>
    <footer>
        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php">Home</a>
                <a href="products.php">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
            </nav>
        </div>
        <div id="sub-foot2">

            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape – your destination for literary
                indulgence."</p>
        </div>
        <div class="sub-foot3">
            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>
            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>
        </div>
        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>
</body>

</html>