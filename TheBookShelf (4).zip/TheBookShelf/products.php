<?php
session_start();
include 'db_conn.php';
$dbConnection = new DatabaseConnection();
$books = $dbConnection->getAllBookDetails();
//setting firstname and lastname from Session
if (isset($_SESSION['email']) && isset($_SESSION['firstname']) && isset($_SESSION['lastname'])) {
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
}

// initialize session
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// book filtering
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['bookType'])) {
    $bookType = $_GET['bookType'];

    //if book type is present filter book
    if (!empty($bookType)) {
        $books = $dbConnection->getBooksByType($bookType);
    } else {
        //if no book is selected show all books
        $books = $dbConnection->getAllBookDetails();
    }

    $booksGenre = $dbConnection->getBooksGenre();

} else {
    $books = $dbConnection->getAllBookDetails();
    $booksGenre = $dbConnection->getBooksGenre();
}

// Code for adding books to cart
if (isset($_POST['book_id']) && (array_key_exists('is_admin', $_SESSION) && !$_SESSION['is_admin'])) {

    if (isset($_SESSION['email'])) {
        $bookId = $_POST['book_id'];
        $bookDetails = $dbConnection->getBookDetailsById($bookId);
        if ($bookDetails) {
            $book_id = $bookDetails['book_id'];
            $book_name = $bookDetails['book_name'];
            $book_description = $bookDetails['book_description'];
            $book_price = $bookDetails['book_price'];
            $book_type = $bookDetails['book_type'];
            $book_author = $bookDetails['book_author'];
            $uploadImage = $bookDetails['uploadImage'];
        }

        $bookAlreadyInCart = false;
        foreach ($_SESSION['cart'] as $item) {
            if ($item['id'] == $book_id) {
                $bookAlreadyInCart = true;
                break;
            }
        }

        // If not in cart, add it
        if (!$bookAlreadyInCart) {
            $_SESSION['cart'][] = array(
                'id' => $book_id,
                'name' => $book_name,
                'description' => $book_description,
                'price' => $book_price,
                'author' => $book_author,
                'total_price' => $book_price,
                'type' => $book_type,
                'quantity' => 1,
                'uploadImage' => $uploadImage,
            );
        }
    }
} else if (isset($_POST['book_id']) && (array_key_exists('is_admin', $_SESSION) && $_SESSION['is_admin'])) {
    if (isset($_SESSION['email'])) {
        $bookId = $_POST['book_id'];
        $result = $dbConnection->deleteBookById($bookId);

        if ($result) {
            echo '<script> alert("Result Deleted Successfully!") </script>';
        } else {
            echo '<script> alert("Result Deletion Failed!") </script>';
        }

        header("Location: products.php");

    }
} else if (isset($_POST['book_id'])) {
    echo '<script> alert("Please Login in with your account first!") </script>';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>The Book Shelf</title>
</head>

<body>

    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php">Home</a>
            <a href="Products.php" class="active">Books</a>

            <?php
            if (!isset($_SESSION['email'])) {
                ?>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
                <a href="login.php">Login</a>
                <?php
            } else {
                if (!$_SESSION['is_admin']) {
                    ?>
                    <a href="about.php">About Us</a>
                    <a href="contact.php">Contact Us</a>
                    <a href="cart.php">Cart</a>
                    <?php
                } else { ?>
                    <a href="add_book.php">Add Book</a>
                    <?php
                }
                ?>
                <a href="logout.php">Logout</a>
            </div>

            <?php
            echo "<div class='profile-name-container'> <div href='#' class='profile-name'>
                    <img src ='Imgs/user.png' alt='profile icon' class='profile-icon'/>
                    <span> 
                        $lastname, $firstname 
                    </span>
                </div>";
            }
            ?>
    </nav>

    <main class="products-main">
        <h3 class="products-heading">Books Gallery</h3>


        <div class="filter-section">
            <form action="products.php" method="GET" class="filter-form">
                <label for="bookType">Filter by Book Type:</label>
                <select id="bookType" name="bookType"
                    value="<?php echo array_key_exists('bookType', $_GET) ? $_GET['bookType'] : ''; ?>">
                    <option value="">All</option>

                    <?php
                    if (!empty($books)) {
                        foreach ($booksGenre as $genre) { ?>

                            <option value="<?php echo $genre['book_type'] ?>" <?php echo (array_key_exists('bookType', $_GET) && $_GET['bookType'] == $genre['book_type']) ? "Selected" : ""; ?>>
                                <?php echo $genre['book_type']; ?>
                            </option>

                            <?php
                        }
                    }
                    ?>

                </select>
                <input type="submit" value="Filter" class="filter-btn" />
            </form>
        </div>

        <div class="products-container">

            <?php
            if (!empty($books)) {
                foreach ($books as $book) { ?>
                    <a href="<?php echo (array_key_exists('is_admin', $_SESSION) && $_SESSION['is_admin']) ? 'update_book.php?bookid=' . $book['book_id'] : 'product_detail.php?bookid=' . $book['book_id']; ?>"
                        class="product-card-a">

                        <div class="product-card">

                            <div class="prod-img-container">
                                <img src="Imgs/uploads/<?php echo $book['uploadImage']; ?>"
                                    alt="<?php echo $book['book_name']; ?>" class="product-image">
                            </div>

                            <h4><?php echo $book['book_name']; ?></h4>

                            <p>
                                By <?php echo $book['book_author']; ?>
                            </p>
                            <div class="price-btn-section">
                                <span
                                    class="product-price"><?php echo '<span class="price-unit">$</span>' . $book['book_price']; ?></span>

                                <form action="products.php" method="POST">
                                    <input type="hidden" name="book_id" value="<?php echo $book['book_id']; ?>">
                                    <?php
                                    if (!isset($_SESSION['email']) || (array_key_exists('is_admin', $_SESSION) && !$_SESSION['is_admin'])) {
                                        $bookAlreadyInCart = false;
                                        foreach ($_SESSION['cart'] as $item) {
                                            if ($item['id'] == $book['book_id']) {
                                                $bookAlreadyInCart = true;
                                                break;
                                            }
                                        }

                                        if ($bookAlreadyInCart) {
                                            echo '<button type="button" class="add-cart-btn" disabled>Added</button>';
                                        } else {
                                            echo '<input type="submit" value="Add To Cart" class="add-cart-btn">';
                                        }
                                    } else {
                                        echo '<input type="submit" value="Delete" class="add-cart-btn">';
                                        ;
                                    }
                                    ?>

                                </form>

                            </div>
                        </div>
                    </a>
                <?php }
            } else {
                echo "No products found.";
            } ?>

        </div>
    </main>
    <footer>
        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php">Home</a>
                <a href="Products.php" class="active">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
            </nav>
        </div>
        <div id="sub-foot2">

            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape – your destination for literary
                indulgence."</p>
        </div>
        <div class="sub-foot3">
            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>
            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>
        </div>
        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>
</body>

</html>