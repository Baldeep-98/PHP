<?php
session_start();
include 'dbinit.php';
include 'db_conn.php';
$firstname = $lastname = "";
// setting firstname and lastname from session
if (isset($_SESSION['email']) && isset($_SESSION['firstname']) && isset($_SESSION['lastname'])) {
    $firstname = $_SESSION['firstname'];
    $lastname = $_SESSION['lastname'];
}

// initialize session
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

$dbConnection = new DatabaseConnection();
$book_id = "";
$book_name = "";
$book_description = "";
$book_price = "";
$book_type = "";
$book_author = "";
$book_uploadImagename = "";


if (isset($dbConnection) && array_key_exists('bookid', $_GET)) {

    $bookid = $_GET['bookid'];

    $bookDetail = $dbConnection->getBookDetailsById($bookid);

    if ($bookDetail) {
        $book_id = $bookDetail['book_id'];
        $book_name = $bookDetail['book_name'];
        $book_description = $bookDetail['book_description'];
        $book_price = $bookDetail['book_price'];
        $book_type = $bookDetail['book_type'];
        $book_author = $bookDetail['book_author'];
        $uploadImage = $bookDetail['uploadImage'];
    } else {
        echo 'console.log("Error in fetching the book data by ID.");</script>';
    }

}

if (isset($_POST['book_id']) && (array_key_exists('is_admin', $_SESSION) && !$_SESSION['is_admin'])) {

    if (isset($_SESSION['email'])) {
        $bookId = $_POST['book_id'];
        $bookDetails = $dbConnection->getBookDetailsById($bookId);
        if ($bookDetails) {
            $book_id = $bookDetails['book_id'];
            $book_name = $bookDetails['book_name'];
            $book_description = $bookDetails['book_description'];
            $book_price = $bookDetails['book_price'];
            $book_type = $bookDetails['book_type'];
            $book_author = $bookDetails['book_author'];
            $uploadImage = $bookDetails['uploadImage'];
        }

        $bookAlreadyInCart = false;
        foreach ($_SESSION['cart'] as $item) {
            if ($item['id'] == $book_id) {
                $bookAlreadyInCart = true;
                break;
            }
        }

        // If not in cart, add it
        if (!$bookAlreadyInCart) {
            $_SESSION['cart'][] = array(
                'id' => $book_id,
                'name' => $book_name,
                'description' => $book_description,
                'price' => $book_price,
                'author' => $book_author,
                'total_price' => $book_price,
                'type' => $book_type,
                'quantity' => 1,
                'uploadImage' => $uploadImage,
            );
        }
    }
} else if (isset($_POST['book_id'])) {
    echo '<script> alert("Please Login in with your account first!") </script>';
    header("Location: login.php");
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Book Detail - Page</title>
</head>

<body>

    <nav>
        <span id="logo">
            <a href="index.php"><img src="Imgs\logo_img.png" alt="logo image" id="logo_img"></a>
        </span>
        <div id="nav_options">
            <a href="index.php">Home</a>
            <a href="Products.php">Books</a>

            <?php
            if (!isset($_SESSION['email'])) {
                ?>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
                <a href="login.php">Login</a>
                <?php
            } else {
                if (!$_SESSION['is_admin']) {
                    ?>
                    <a href="about.php">About Us</a>
                    <a href="contact.php">Contact Us</a>
                    <a href="cart.php">Cart</a>
                    <?php
                } else { ?>
                    <a href="add_book.php">Add Book</a>
                    <?php
                }
                ?>
                <a href="logout.php">Logout</a>
            </div>

            <?php
            echo "<div class='profile-name-container'> <div href='#' class='profile-name'>
                        <img src ='Imgs/user.png' alt='profile icon' class='profile-icon'/>
                        <span> 
                            $lastname, $firstname 
                        </span>
                    </div>";
            }
            ?>
    </nav>

    <main class="detail-container">
        <div class="detail-section">

            <div class="detail-subsection1">
                <img src="Imgs/uploads/<?php echo isset($uploadImage) ? $uploadImage : ''; ?>"
                    alt="<?php echo $uploadImage . ' image'; ?>" class="product-image prod-desc-img">
            </div>
            <div class="detail-subsection2">
                <h2 class="prod-desc-name"> <?php echo isset($book_name) ? $book_name : ''; ?> </h2>
                <p class="detail-author-name">By <?php echo isset($book_author) ? $book_author : ''; ?> </p>
                <h3> <span class="price-unit">$</span> <?php echo isset($book_price) ? $book_price : ''; ?> </h3>
                <p class="prod-detail-attribute"> <em>ID - </em> <?php echo isset($book_id) ? $book_id : ''; ?> </p>
                <p class="prod-detail-attribute"> <em>Type - </em> <?php echo isset($book_type) ? $book_type : ''; ?>
                </p>
                <p class="prod-detail-desc"> <?php echo isset($book_description) ? $book_description : ''; ?> </p>
                <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                    <input type="hidden" name="book_id" value="<?php echo $book_id; ?>">
                    <?php
                    if (!isset($_SESSION['email']) || (array_key_exists('is_admin', $_SESSION) && !$_SESSION['is_admin'])) {
                        $bookAlreadyInCart = false;
                        foreach ($_SESSION['cart'] as $item) {
                            if ($item['id'] == $book_id) {
                                $bookAlreadyInCart = true;
                                break;
                            }
                        }

                        if ($bookAlreadyInCart) {
                            echo '<button type="button" class="add-cart-btn detail-card-btn" disabled>Added</button>';
                        } else {
                            echo '<input type="submit" value="Add To Cart" class="add-cart-btn detail-card-btn">';
                        }
                    }
                    ?>

                </form>
            </div>
        </div>

    </main>

    <footer>

        <div id="sub-foot1">
            <h2>Quick links</h2>
            <nav>
                <a href="index.php" class="active">Home</a>
                <a href="Products.php">Books</a>
                <a href="about.php">About Us</a>
                <a href="contact.php">Contact Us</a>
            </nav>
        </div>

        <div id="sub-foot2">

            <h2>Our Speciality</h2>
            <p>Story and literature Books</p>
            <p>"Elevating your reading experience with curated collections at Shelfscape – your destination for literary
                indulgence."</p>

        </div>

        <div class="sub-foot3">

            <span id="foot_logo">
                <a href="index.php"><img src="Imgs\logo_img.png" alt="logo_img" id="foot_logo_img"></a>
            </span>
            <p id="logo_line"> Where every page holds a new adventure.</p>

            <div id="social_network_links">
                <p>Join our network:</p>
                <a href="#"><img src="Imgs\foot_fb.svg" alt="Facebook"></a>
                <a href="#"><img src="Imgs\foot_ig.svg" alt="Instagram"></a>
                <a href="#"><img src="Imgs\foot_tw.svg" alt="Twitter"></a>
                <a href="#"><img src="Imgs\foot_yt.svg" alt="Youtube"></a>
            </div>

        </div>

        <p id="copyright">Copyright &copy; 2024 <em>The BookShelf</em> created by members of Group #2</p>
    </footer>
</body>

</html>